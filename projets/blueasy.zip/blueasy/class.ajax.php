<?php

class {
  public function __construct(){

  }

  public function formHtml(){

  }

  public function formAjax(){

  }


}
